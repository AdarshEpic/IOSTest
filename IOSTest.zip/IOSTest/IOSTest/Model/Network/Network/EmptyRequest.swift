//
//  EmptyRequest.swift
//  IOSTest
//
//  Created by Adarsh Manoharan on 18/04/2 R.
//  Copyright © 2 Adarsh Manoharan. All rights reserved.
//

import Foundation

//Use When no request body needed
struct EmptyRequest: Encodable {
    
}
