# IOSTest
iOS Test Project

Usage (master)
Default branch is master

1. Download or Clone from "https://github.com/AdarshEpic/IOSTest.git"
2. open terminal or open pod installer tool
3. choose directory as Path -> IOSTest
4. run pod install (terminal)
5. start try to run with "IOSTest.xcworkspace"
