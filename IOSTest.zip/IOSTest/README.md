# IOSTest
iOS Test Project

Usage (master)
Default branch is master

1. Download or Clone from "https://github.com/AdarshEpic/IOSTest.git"
2. open terminal or open pod installer tool
3. choose directory as Path -> IOSTest
4. run pod deintegrate (terminal)
OR
4. insted of 4 -> delete "Pods" directory and the  "IOSTest.xcworkspace" file and continue with 5th step
5. run pod install (terminal)
6. start try to run with "IOSTest.xcworkspace"

Dependencies

Cocoa pod Version  ~> 1.9.1
XCODE Version ~> 13.3.1
Swift Version -> 5.2
iOS targeted Version -> 11 and above

Usage Problems on pods and other user the zip file attached with the project
If you are trouble with pods use bellow link to download the project
"https://github.com/AdarshEpic/IOSTest/raw/master/IOSTest.zip"

Thank you
