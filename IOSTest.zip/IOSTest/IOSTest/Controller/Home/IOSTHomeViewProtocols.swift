//
//  IOSTHomeViewProtocols.swift
//  IOSTest
//
//  Created by Adarsh Manoharan on 17/04/2 R.
//  Copyright © 2 Adarsh Manoharan. All rights reserved.
//

import Foundation
//HomeView Protocols
protocol IOSTHomeViewControllerProtocol {
    func setupNavigationTitle(title: String)
}
